# NAMEWORLD — Android project

Projecto Android nativo (Kotlin + WebView) com interface local em HTML/CSS/JavaScript.

## O que já funciona
- Pesquisa de nomes e apelidos.
- Consulta externa das páginas de distribuição de nomes do Forebears.
- Pesquisa alternativa na Web.
- Histórico local das últimas 8 pesquisas.
- Partilha da pesquisa através do menu nativo Android.
- Interface adaptada a telemóveis e funcionamento da interface sem ligação à Internet.

## Limitação importante dos dados
O projecto não inventa contagens. Não existe uma API pública universal e confirmada que devolva uma contagem mundial em tempo real. Ao consultar estatísticas, a aplicação abre a fonte externa (Forebears) no navegador. A disponibilidade e cobertura variam por nome e país. A ligação à Internet é necessária para consultar fontes externas.

## Como gerar o APK no Android Studio
1. Instale Android Studio (versão recente) e o Android SDK Platform 35.
2. Abra a pasta `NAMEWORLD` no Android Studio.
3. Aguarde a sincronização do Gradle e permita a instalação dos componentes solicitados.
4. Seleccione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de teste será gerado em `app/build/outputs/apk/debug/app-debug.apk`.
6. Para distribuir publicamente, crie uma chave de assinatura e use **Build > Generate Signed Bundle / APK** para gerar um APK release assinado.

## Requisitos técnicos
- Android Studio com JDK 17 ou superior.
- Android SDK 35.
- Gradle 8.9+ (o Android Studio pode gerir a instalação do Gradle).
- Android 6.0 (API 23) ou superior.

## Identidade
- Nome: NAMEWORLD
- Application ID: `com.nameworld.app`
- Versão: 1.0.0

Este pacote contém o projecto-fonte Android pronto para abrir e compilar no Android Studio. Não contém um APK pré-compilado nem uma chave privada de assinatura.
